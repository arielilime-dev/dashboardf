"""Conteúdo editorial demonstrativo; temas sujeitos a revisão antes de publicação."""
from datetime import date

CATEGORIES = [
    "Organização financeira",
    "Dívidas e crédito",
    "Economia no dia a dia",
    "Reserva e metas",
    "Investimentos para iniciantes",
    "Renda e carreira",
    "Ferramentas",
]

ARTICLES = [
    {
        "slug": "orcamento-mensal-em-5-etapas",
        "title": "Como montar um orçamento mensal em 5 etapas",
        "summary": "Um roteiro simples para entender o que entra, o que sai e quanto cabe nos seus planos.",
        "category": "Organização financeira",
        "level": "Iniciante",
        "tags": ["planejamento", "primeiros passos", "mês"],
        "minutes": 6,
        "updated": "4 de novembro de 2026",
        "intro": "Um orçamento funciona melhor quando descreve a sua realidade, não uma rotina ideal. Comece com um retrato honesto do mês e ajuste os limites à medida que aprende com os próprios registros.",
        "sections": [
            {"heading": "1. Registre a renda que realmente recebe", "paragraph": "Anote as entradas líquidas e as datas em que costumam chegar. Se a sua renda varia, use um valor conservador para as despesas essenciais e trate entradas extras como incertas até que sejam confirmadas."},
            {"heading": "2. Separe despesas fixas, variáveis e ocasionais", "paragraph": "Moradia e serviços recorrentes costumam ser mais previsíveis. Alimentação e transporte variam; seguros e manutenção podem aparecer em intervalos maiores. Registrar as datas ajuda a não confundir uma conta anual com um gasto inesperado."},
            {"heading": "3. Escolha limites que façam sentido", "paragraph": "Use o histórico como ponto de partida. Um limite é uma referência para decidir, não uma promessa de que todo mês será igual. Se uma categoria ultrapassar o planejado, anote o motivo antes de cortar algo importante."},
            {"heading": "4. Planeje os objetivos junto com as contas", "paragraph": "Inclua a reserva ou outras metas como linhas visíveis do plano. Começar com um valor sustentável costuma ser mais fácil de manter do que escolher uma quantia que deixa o cotidiano apertado."},
            {"heading": "5. Revise durante o mês", "paragraph": "Uma conferência breve por semana permite corrigir a rota antes do fechamento. Compare o planejado com o confirmado e marque o que ainda é estimativa para não contar a mesma saída duas vezes."},
        ],
        "example": "Exemplo ilustrativo: se o valor destinado a alimentação costuma variar, registre compras separadas por data e confira o total semanalmente. Não use uma única compra fora do padrão para concluir que todo o seu orçamento precisa mudar.",
        "action": "Abra Orçamento e escolha limites iniciais para as categorias mais frequentes.",
        "faq": [
            {"question": "Preciso usar uma planilha?", "answer": "Não. Use um caderno, uma planilha ou um app, desde que consiga revisar valores e datas com regularidade."},
            {"question": "E se a renda mudar todo mês?", "answer": "Planeje os compromissos essenciais com uma estimativa cautelosa e revise o plano quando a renda se confirmar."},
        ],
        "related": ["reserva-de-emergencia-como-planejar", "revisar-assinaturas-e-gastos-recorrentes"],
        "references": [],
    },
    {
        "slug": "reserva-de-emergencia-como-planejar",
        "title": "Reserva de emergência: como planejar um objetivo possível",
        "summary": "Transforme uma meta ampla em um valor de referência, um prazo e contribuições que caibam na rotina.",
        "category": "Reserva e metas",
        "level": "Iniciante",
        "tags": ["reserva", "metas", "planejamento"],
        "minutes": 5,
        "updated": "4 de novembro de 2026",
        "intro": "Uma reserva é um objetivo de organização, não uma garantia contra todos os imprevistos. Planejar começa por conhecer as despesas essenciais e escolher um ritmo realista para formar esse colchão.",
        "sections": [
            {"heading": "Identifique o que é essencial", "paragraph": "Liste despesas que sustentam moradia, alimentação, transporte necessário, saúde e compromissos prioritários. Separe esses itens de gastos que podem ser temporariamente reduzidos."},
            {"heading": "Escolha uma meta inicial", "paragraph": "Você pode começar com uma etapa menor e revisar o objetivo depois. O número de meses usado como referência depende de estabilidade da renda, responsabilidades e acesso a outras fontes de apoio; não existe um prazo único adequado a todos."},
            {"heading": "Defina uma contribuição que consiga repetir", "paragraph": "Uma contribuição modesta e frequente pode tornar o progresso visível. Se um mês for atípico, revise o plano sem tratar a pausa como fracasso."},
            {"heading": "Separe meta de produto financeiro", "paragraph": "A calculadora desta página faz apenas uma conta de despesas mensais vezes meses de cobertura escolhidos. Ela não recomenda produto, rendimento, instituição ou prazo de resgate. Compare características e riscos antes de tomar decisões."},
        ],
        "example": "Exemplo ilustrativo: com despesas essenciais estimadas em R$ 2.000 e uma meta escolhida de 3 meses, o valor de referência seria R$ 6.000. É apenas uma multiplicação para organizar a meta, não uma recomendação financeira.",
        "action": "Use a calculadora de reserva para estimar um valor de referência e registre a meta na página Metas.",
        "faq": [
            {"question": "Qual é o prazo ideal para formar a reserva?", "answer": "O prazo depende da sua renda, das despesas essenciais e das demais responsabilidades. Escolha um ritmo que não comprometa contas prioritárias."},
            {"question": "A calculadora indica onde investir?", "answer": "Não. Ela estima somente o valor-alvo a partir dos dados informados."},
        ],
        "related": ["orcamento-mensal-em-5-etapas", "investir-com-objetivos-e-riscos"],
        "references": [],
    },
    {
        "slug": "revisar-assinaturas-e-gastos-recorrentes",
        "title": "Como revisar assinaturas e gastos recorrentes",
        "summary": "Uma revisão prática para identificar cobranças, confirmar usos e decidir o que manter.",
        "category": "Economia no dia a dia",
        "level": "Intermediário",
        "tags": ["economia", "recorrentes", "checklist"],
        "minutes": 4,
        "updated": "4 de novembro de 2026",
        "intro": "Cobranças recorrentes são fáceis de esquecer porque aparecem em datas diferentes. Uma revisão periódica ajuda a tomar decisões com base no uso e no orçamento, sem assumir que todo serviço é dispensável.",
        "sections": [
            {"heading": "Reúna as cobranças", "paragraph": "Confira faturas, extratos e comprovantes do período escolhido. Registre nome, valor, frequência e forma de pagamento. Valores de teste podem aparecer em moedas diferentes; anote a moeda corretamente."},
            {"heading": "Confirme o uso e as condições", "paragraph": "Para cada serviço, pergunte quando foi usado pela última vez, se existe uma alternativa e quais regras se aplicam ao cancelamento. Consulte diretamente o fornecedor antes de alterar uma assinatura."},
            {"heading": "Decida sem duplicar cortes", "paragraph": "Classifique o que manter, revisar ou cancelar. Registre a decisão e a data de renovação; confirme o resultado na próxima fatura. Evite contar como economia uma cobrança que ainda não deixou de ocorrer."},
        ],
        "example": "Exemplo ilustrativo: se dois serviços parecem semelhantes, compare a frequência de uso e os recursos de cada um antes de cancelar. Uma cobrança pequena pode ser essencial para determinada pessoa.",
        "action": "Na página Movimentações, filtre despesas recorrentes e revise as próximas datas de cobrança.",
        "faq": [
            {"question": "Com que frequência devo revisar?", "answer": "Escolha uma periodicidade que funcione para a sua rotina, como uma revisão mensal ou trimestral."},
            {"question": "O painel cancela assinaturas por mim?", "answer": "Não. Ele ajuda a organizar os registros; alterações devem ser feitas com o prestador do serviço."},
        ],
        "related": ["orcamento-mensal-em-5-etapas", "cartao-de-credito-como-acompanhar"],
        "references": [],
    },
    {
        "slug": "investir-com-objetivos-e-riscos",
        "title": "Começar a investir: objetivos, prazo e riscos",
        "summary": "Perguntas para organizar sua pesquisa antes de comparar opções de investimento.",
        "category": "Investimentos para iniciantes",
        "level": "Iniciante",
        "tags": ["investimentos", "risco", "objetivos"],
        "minutes": 5,
        "updated": "4 de novembro de 2026",
        "intro": "Antes de comparar produtos, vale entender para que serve o dinheiro e quando ele poderá ser necessário. Este guia apresenta perguntas de organização e não recomenda ativos ou estratégias.",
        "sections": [
            {"heading": "Defina o objetivo e o prazo", "paragraph": "Uma meta de curto prazo pode exigir acesso diferente de um objetivo distante. Registre o valor, a data pretendida e o que mudaria caso o plano atrasasse."},
            {"heading": "Entenda como o risco se manifesta", "paragraph": "Risco pode envolver oscilação de preço, dificuldade de resgate, concentração, crédito ou regras do produto. Leia os documentos atuais da instituição e procure ajuda qualificada quando necessário."},
            {"heading": "Verifique custos, liquidez e condições", "paragraph": "Compare custos totais, prazos para resgate, tributação aplicável e regras vigentes em fontes oficiais. Não tome decisões apenas com base em rentabilidade passada ou em exemplos de outras pessoas."},
        ],
        "example": "Exemplo ilustrativo: se o objetivo depende de uma data próxima, verifique com cuidado se o produto permite acesso ao valor quando necessário. Essa reflexão não determina qual produto escolher.",
        "action": "Registre o objetivo e o prazo na página Metas antes de comparar produtos.",
        "faq": [
            {"question": "Existe investimento sem risco?", "answer": "Produtos e situações diferentes apresentam riscos distintos. Leia as condições oficiais e considere se elas são compatíveis com sua necessidade."},
            {"question": "O conteúdo recomenda um ativo?", "answer": "Não. É material educativo geral, sem recomendação individual."},
        ],
        "related": ["reserva-de-emergencia-como-planejar", "orcamento-mensal-em-5-etapas"],
        "references": [],
    },
    {
        "slug": "cartao-de-credito-como-acompanhar",
        "title": "Cartão de crédito: como acompanhar a fatura",
        "summary": "Organize compras, vencimentos e parcelas para entender o compromisso assumido.",
        "category": "Dívidas e crédito",
        "level": "Iniciante",
        "tags": ["cartão", "fatura", "organização"],
        "minutes": 4,
        "updated": "4 de novembro de 2026",
        "intro": "O cartão facilita pagamentos, mas as compras continuam sendo compromissos do orçamento. Acompanhar datas e parcelas ajuda a enxergar o que já foi assumido antes do fechamento da fatura.",
        "sections": [
            {"heading": "Registre cada compra uma única vez", "paragraph": "Escolha um método para anotar compras e parcelas. Evite somar a compra e o pagamento da fatura como duas despesas diferentes no mesmo relatório."},
            {"heading": "Confira fechamento e vencimento", "paragraph": "Consulte as datas diretamente na instituição emissora. Uma compra pode entrar em uma fatura diferente dependendo da data de processamento."},
            {"heading": "Aja cedo diante de dificuldades", "paragraph": "Se não puder pagar a fatura como previsto, fale com a instituição e confira as condições vigentes antes de aceitar uma alternativa. Compare o custo total, o prazo e as consequências."},
        ],
        "example": "Exemplo ilustrativo: a compra parcelada compromete partes de meses futuros. Ao avaliar uma nova compra, considere as parcelas já contratadas, além dos gastos do mês atual.",
        "action": "Cadastre o vencimento na página Contas e cartões e revise as próximas parcelas.",
        "faq": [
            {"question": "Devo lançar a compra ou o pagamento da fatura?", "answer": "Escolha uma convenção e mantenha-a; este painel considera cada compra como despesa e não deve duplicá-la ao marcar a fatura como paga."},
            {"question": "O site consulta meu cartão?", "answer": "Não. Os registros são digitados pelo usuário e ficam no navegador."},
        ],
        "related": ["revisar-assinaturas-e-gastos-recorrentes", "orcamento-mensal-em-5-etapas"],
        "references": [],
    },
]

ARTICLE_BY_SLUG = {article["slug"]: article for article in ARTICLES}


def articles_updated() -> str:
    return date.today().strftime("%d/%m/%Y")
