# FinFlow — plano de implementação

## Produto e escopo

Criar um site funcional de controle financeiro em português brasileiro, combinando um dashboard e uma central de aprendizado. A implementação será Python com Flask e templates Jinja; o navegador usa HTML, CSS e JavaScript para formulários, filtros e gráficos interativos. O projeto flexível está vazio em `/home/ubuntu/finflow`, com servidor gerenciado habilitado e porta de Preview 3000. Não há banco de dados ou autenticação solicitados.

Proposta sujeita à aprovação: uma primeira versão pessoal demonstrativa, com receitas, despesas, orçamentos, contas, metas e artigos navegáveis. As alterações ficam no navegador deste dispositivo (localStorage), sem contas de usuário, sincronização, conexão bancária ou envio de dados pessoais a um banco compartilhado. O servidor Python recebe os dados fornecidos pelo próprio navegador apenas para validar e calcular os resumos, sem guardá-los. A interface avisa que os dados iniciais são fictícios e que o armazenamento local não substitui um backup. Haverá exportação CSV das movimentações e backup/restauração JSON. Login e persistência segura no servidor serão uma futura evolução, não recursos simulados.

## Funcionalidades

- Visão geral com período selecionável, saldo de todas as movimentações até o fim do período, receitas e despesas do período, orçamento restante, comparação do mês em curso com os mesmos dias do mês anterior (e de meses completos entre si), gráfico mensal de receitas/despesas, gastos por categoria, movimentações recentes e progresso das metas.
- Alertas acionáveis sobre orçamento e contas a vencer, com data e status claros; valores futuros apresentados como estimativas informadas pelo usuário, distinguíveis de valores confirmados; dados fictícios coerentes e atualizados para o mês em curso.
- Movimentações com busca, filtros de tipo e categoria, cadastro/edição/exclusão de receitas e despesas e exportação CSV; valores positivos e datas válidas, movimentações pendentes distintas das confirmadas.
- Orçamento com limites editáveis por categoria e estados textuais de consumo, incluindo valores acima do limite sem falsear as barras.
- Contas e cartões com vencimentos e status; atraso derivado da data; marcação local de pagamento com escolha explícita sobre registrar ou não o total como despesa, para evitar duplicar compras já lançadas individualmente.
- Metas com progresso e contribuição local editável; sem alegar movimentação real de dinheiro.
- Relatórios com análise por categoria e por mês, construída a partir das mesmas movimentações, não números decorativos.
- Aprenda com as sete categorias sugeridas: Organização financeira, Dívidas e crédito, Economia no dia a dia, Reserva e metas, Investimentos para iniciantes, Renda e carreira e Ferramentas. Busca por assunto, filtros por categoria e nível, tags e entradas por objetivo.
- Artigos renderizados no Python com título, resumo, categoria, leitura estimada, atualização, breadcrumb, índice, exemplos ilustrativos, próximo passo, dúvidas e links relacionados. Sem alegações de taxas, legislação ou rentabilidade atuais não verificadas. Uma calculadora de reserva usa despesas essenciais e meses escolhidos pelo usuário.
- Navegação lateral no desktop, navegação móvel acessível, botão de ocultar valores, feedback em formulários e navegação por teclado.

## Implementação, dependências e execução

Flask serve páginas completas e arquivos estáticos na mesma origem, sem bundler ou backend Node. JavaScript modular e CSS próprios reduzem dependências; gráficos de barras usam HTML/CSS responsivo com legendas, títulos e descrições textuais acessíveis. Python valida tipos monetários em centavos, formatos e limites antes de calcular. Não há persistência de dados pessoais no servidor.

Dependências Python fixadas em `requirements.txt`, ambiente virtual local, `app.py` para desenvolvimento e Gunicorn como servidor de produção. `Dockerfile` instala as mesmas dependências e inicia o app na variável `PORT`, por padrão 3000. Health check público em `/api/health`. `manus-routes.json` declara todas as páginas e o padrão de artigo. Deploy será configurado para container; o checkpoint será salvo no repositório Manus. O site será entregue no Preview; publicação pública é separada e não será alegada sem confirmação.

Artigos e páginas de descoberta têm corpo e metadados no HTML inicial. Páginas financeiras terão `noindex` e `Cache-Control: private, no-store`. Canonical, sitemap e endereço Open Graph só usam uma origem pública explícita; nenhuma URL interna será apresentada como domínio definitivo. Não serão adicionadas fotografias decorativas ao dashboard; ativos necessários são a tipografia e um símbolo geométrico de marca.

## Estrutura do projeto

- `app.py`: criação Flask, rotas de páginas, health check, endpoints de validação e cálculo.
- `finance/`: cálculos em centavos e validação de entradas, separados da camada web.
- `content/`: catálogo editorial estruturado e referências de ativos/fontes.
- `templates/`: layout comum, painel, páginas financeiras, listagem editorial e artigo.
- `static/css/`: tokens visuais, componentes e estilos responsivos.
- `static/js/`: estado local, cliente da API, formulários, gráficos e filtros.
- `static/brand/`: símbolo da marca e favicon.
- `tests/`: testes dos cálculos, endpoints, status HTTP e rotas.
- `requirements.txt`, `Dockerfile`, `.gitignore`, `README.md`, `app.config.ts`: dependências, execução, documentação e metadata de projeto.
- `plan.md`, `TODO.md`: direção acordada e resultados entregáveis.

## Direções visuais consideradas

1. Modernismo suíço aplicado a finanças: contraste sóbrio, números destacados e verde-menta funcional (probabilidade 0,07).
2. Editorial analógico: tons creme, tipografia serifada e organização semelhante a um caderno financeiro (probabilidade 0,04).
3. Minimalismo tecnológico noturno: superfície grafite e acentos lavanda, com foco em monitoramento (probabilidade 0,06).

Direção proposta: modernismo suíço aplicado a finanças.

### Design Movement

Modernismo suíço contemporâneo com acabamento de produto financeiro: assimetria controlada, alinhamento preciso e informação hierarquizada.

### Core Principles

Leitura rápida dos indicadores; número acompanhado de contexto; cor apenas onde existe significado; transição direta de informação para ação.

### Color Philosophy

Fundo cinza quase branco, superfícies brancas e texto grafite para baixa carga visual. Verde-menta para progresso e ações; coral suave para despesas e âmbar para atenção. Estados possuem texto além da cor.

### Layout Paradigm

Navegação lateral estreita, cabeçalho utilitário e coluna principal fluida. Indicadores em faixa horizontal; análise de fluxo ocupa a maior largura e categorias ficam na coluna adjacente. Abaixo, transações e contas mantêm hierarquia desigual; conteúdo editorial não compete com os números.

### Signature Elements

Símbolo de dois traços ascendentes encaixados; borda arredondada discreta; cápsulas de estado e etiquetas monoespaçadas para datas e categorias.

### Interaction Philosophy

Ações curtas com confirmação apenas em exclusões e substituição de backup. Formulários em modal acessível; botões descrevem a ação, filtros reagem imediatamente e vazios orientam o próximo passo.

### Animation

Entrada de módulos por opacidade e deslocamento de até 8 px em 180 ms; hover de 140 ms; gráficos com transição leve de 220 ms. Respeitar `prefers-reduced-motion` e não animar valores monetários como contadores.

### Typography System

Manrope para marca, títulos e números; Inter para interface e texto de artigos, com fontes alternativas do sistema. Títulos entre 26 e 34 px, texto de interface 13–15 px, números principais 27–34 px com algarismos tabulares. Artigos com corpo de 17 px e entrelinha 1,7.

### Brand Essence

FinFlow organiza o dinheiro e oferece o próximo passo para quem quer clareza sem complicação. Personalidade: clara, serena, prática.

### Brand Voice

Direta e acolhedora, sem promessas de enriquecimento. Exemplos: “Seu dinheiro, com mais clareza.” e “Falta pouco para fechar o mês dentro do plano.”

### Wordmark & Logo

Marca `finflow` em letras minúsculas com espaçamento compacto e símbolo geométrico de fluxo ascendente à esquerda, construído em SVG original.

### Signature Brand Color

Verde-menta profundo `#1A9E75`, com `#E4F5EE` em fundos de apoio.
