"""Validação e cálculos financeiros sem persistência no servidor."""
from __future__ import annotations

from calendar import monthrange
from datetime import date, datetime
from typing import Any

MAX_CENTS = 100_000_000_000
MAX_TRANSACTIONS = 2_000
VALID_TYPES = {"receita", "despesa"}
VALID_STATUSES = {"confirmada", "pendente"}


class FinanceInputError(ValueError):
    """Entrada financeira inválida ou fora dos limites permitidos."""


def _integer(value: Any, field: str, *, minimum: int = 0, maximum: int = MAX_CENTS) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise FinanceInputError(f"O campo {field} precisa ser um valor inteiro válido.")
    return value


def validate_data(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise FinanceInputError("Envie um objeto com os dados financeiros.")
    transactions = data.get("transactions", [])
    budgets = data.get("budgets", [])
    bills = data.get("bills", [])
    goals = data.get("goals", [])
    if not isinstance(transactions, list) or len(transactions) > MAX_TRANSACTIONS:
        raise FinanceInputError("A lista de movimentações excede o limite permitido.")
    for key, collection in (("orçamentos", budgets), ("contas", bills), ("metas", goals)):
        if not isinstance(collection, list) or len(collection) > 200:
            raise FinanceInputError(f"A lista de {key} não é válida.")

    clean_transactions: list[dict[str, Any]] = []
    for item in transactions:
        if not isinstance(item, dict):
            raise FinanceInputError("Cada movimentação precisa ser um objeto.")
        try:
            datetime.strptime(item.get("date", ""), "%Y-%m-%d")
        except (TypeError, ValueError):
            raise FinanceInputError("Use uma data válida no formato AAAA-MM-DD.") from None
        movement_type = item.get("type")
        status = item.get("status", "confirmada")
        description = item.get("description", "")
        category = item.get("category", "")
        identifier = item.get("id", "")
        if movement_type not in VALID_TYPES or status not in VALID_STATUSES:
            raise FinanceInputError("O tipo ou o status da movimentação não é válido.")
        if not isinstance(description, str) or not 1 <= len(description.strip()) <= 100:
            raise FinanceInputError("A descrição deve ter entre 1 e 100 caracteres.")
        if not isinstance(category, str) or len(category.strip()) > 60:
            raise FinanceInputError("A categoria deve ter no máximo 60 caracteres.")
        if not isinstance(identifier, str) or not 1 <= len(identifier) <= 100:
            raise FinanceInputError("O identificador da movimentação não é válido.")
        clean_transactions.append({
            "id": identifier,
            "date": item["date"],
            "description": description.strip(),
            "category": category.strip() or "Sem categoria",
            "type": movement_type,
            "status": status,
            "amount_cents": _integer(item.get("amount_cents"), "valor", minimum=1),
        })

    clean_budgets: list[dict[str, Any]] = []
    for item in budgets:
        if not isinstance(item, dict) or not isinstance(item.get("category"), str):
            raise FinanceInputError("Há um orçamento com categoria inválida.")
        category = item["category"].strip()
        if not category or len(category) > 60:
            raise FinanceInputError("O nome da categoria do orçamento não é válido.")
        clean_budgets.append({
            "category": category,
            "limit_cents": _integer(item.get("limit_cents"), "limite do orçamento"),
        })

    clean_bills: list[dict[str, Any]] = []
    for item in bills:
        if not isinstance(item, dict):
            raise FinanceInputError("Há uma conta com formato inválido.")
        try:
            datetime.strptime(item.get("due_date", ""), "%Y-%m-%d")
        except (TypeError, ValueError):
            raise FinanceInputError("Uma conta tem vencimento inválido.") from None
        if item.get("status") not in {"a_vencer", "paga", "atrasada"}:
            raise FinanceInputError("O status de uma conta não é válido.")
        if not isinstance(item.get("name"), str) or not 1 <= len(item["name"].strip()) <= 100:
            raise FinanceInputError("O nome de uma conta não é válido.")
        clean_bills.append({
            "id": str(item.get("id", ""))[:100],
            "name": item["name"].strip(),
            "category": str(item.get("category", "Outros"))[:60],
            "due_date": item["due_date"],
            "status": item["status"],
            "amount_cents": _integer(item.get("amount_cents"), "valor da conta", minimum=1),
            "transaction_id": str(item.get("transaction_id", ""))[:100],
        })

    clean_goals: list[dict[str, Any]] = []
    for item in goals:
        if not isinstance(item, dict):
            raise FinanceInputError("Há uma meta com formato inválido.")
        name = item.get("name", "")
        if not isinstance(name, str) or not 1 <= len(name.strip()) <= 80:
            raise FinanceInputError("O nome de uma meta não é válido.")
        target = _integer(item.get("target_cents"), "valor-alvo da meta", minimum=1)
        current = _integer(item.get("current_cents"), "progresso da meta")
        clean_goals.append({
            "id": str(item.get("id", ""))[:100],
            "name": name.strip(),
            "target_cents": target,
            "current_cents": min(current, target),
            "monthly_cents": _integer(item.get("monthly_cents", 0), "contribuição mensal"),
        })

    return {
        "initial_balance_cents": _integer(data.get("initial_balance_cents", 0), "saldo inicial"),
        "transactions": clean_transactions,
        "budgets": clean_budgets,
        "bills": clean_bills,
        "goals": clean_goals,
    }


def _month_start(value: date) -> date:
    return value.replace(day=1)


def _shift_month(value: date, offset: int) -> date:
    index = value.year * 12 + value.month - 1 + offset
    year, month_zero = divmod(index, 12)
    return date(year, month_zero + 1, 1)


def _month_end(value: date) -> date:
    return date(value.year, value.month, monthrange(value.year, value.month)[1])


def _cents_label(value: int) -> str:
    return f"R$ {value / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def calculate_summary(raw_data: Any, today: date | None = None, period: str = "current") -> dict[str, Any]:
    data = validate_data(raw_data)
    today = today or date.today()
    current_start = _month_start(today)
    previous_start = _shift_month(current_start, -1)
    previous_end = _month_end(previous_start)
    month_names = ("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")
    month_abbreviations = ("jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez")
    if period == "previous":
        start, end = previous_start, previous_end
        label = f"{month_names[start.month - 1].capitalize()} de {start.year}"
        comparison_start = _shift_month(start, -1)
        comparison_end = _month_end(comparison_start)
        comparison_label = "em relação ao mês anterior"
    elif period == "six_months":
        start, end = _shift_month(current_start, -5), today
        label = "Últimos 6 meses"
        comparison_start = comparison_end = None
        comparison_label = None
    elif period == "current":
        start, end = current_start, today
        label = f"{month_names[today.month - 1].capitalize()} de {today.year}"
        comparison_start = previous_start
        comparison_end = date(previous_start.year, previous_start.month, min(today.day, monthrange(previous_start.year, previous_start.month)[1]))
        comparison_label = "em relação aos mesmos dias do mês anterior"
    else:
        raise FinanceInputError("O período selecionado não é válido.")

    transactions = data["transactions"]

    def is_confirmed(item: dict[str, Any]) -> bool:
        return item["status"] == "confirmada"

    def between(item: dict[str, Any], from_date: date, to_date: date) -> bool:
        item_date = date.fromisoformat(item["date"])
        return from_date <= item_date <= to_date and is_confirmed(item)

    def total(movement_type: str, from_date: date, to_date: date) -> int:
        return sum(
            item["amount_cents"] for item in transactions
            if item["type"] == movement_type and between(item, from_date, to_date)
        )

    income = total("receita", start, end)
    expenses = total("despesa", start, end)
    comparison_income = total("receita", comparison_start, comparison_end) if comparison_start and comparison_end else None
    comparison_expenses = total("despesa", comparison_start, comparison_end) if comparison_start and comparison_end else None
    balance = data["initial_balance_cents"] + sum(
        item["amount_cents"] * (1 if item["type"] == "receita" else -1)
        for item in transactions
        if is_confirmed(item) and date.fromisoformat(item["date"]) <= today
    )

    spending: dict[str, int] = {}
    period_spending: dict[str, int] = {}
    for item in transactions:
        if item["type"] != "despesa":
            continue
        if between(item, current_start, today):
            spending[item["category"]] = spending.get(item["category"], 0) + item["amount_cents"]
        if between(item, start, end):
            period_spending[item["category"]] = period_spending.get(item["category"], 0) + item["amount_cents"]

    budgets = data["budgets"]
    budget_total = sum(item["limit_cents"] for item in budgets)
    budget_spent = sum(spending.get(item["category"], 0) for item in budgets)
    budget_remaining = budget_total - budget_spent
    budget_rows = []
    for item in budgets:
        spent = spending.get(item["category"], 0)
        limit = item["limit_cents"]
        ratio = round(spent / limit * 100) if limit else (100 if spent else 0)
        state = "acima do limite" if spent > limit else "perto do limite" if ratio >= 80 else "dentro do limite"
        budget_rows.append({**item, "spent_cents": spent, "ratio": ratio, "state": state})
    budget_rows.sort(key=lambda item: item["spent_cents"], reverse=True)

    category_rows = sorted(period_spending.items(), key=lambda item: item[1], reverse=True)
    if period == "current":
        series_start = _shift_month(current_start, -5)
        series_end = today
    elif period == "previous":
        series_start = _shift_month(previous_start, -5)
        series_end = previous_end
    else:
        series_start, series_end = start, end
    months = []
    cursor = _month_start(series_start)
    while cursor <= _month_start(series_end):
        month_end = min(_month_end(cursor), series_end)
        in_cents = total("receita", cursor, month_end)
        out_cents = total("despesa", cursor, month_end)
        months.append({
            "key": cursor.strftime("%Y-%m"),
            "label": month_abbreviations[cursor.month - 1],
            "income_cents": in_cents,
            "expense_cents": out_cents,
        })
        cursor = _shift_month(cursor, 1)

    account_rows = sorted(data["bills"], key=lambda item: item["due_date"])
    alerts = []
    for item in budget_rows:
        if item["ratio"] >= 80:
            alerts.append({
                "level": "danger" if item["spent_cents"] > item["limit_cents"] else "warning",
                "text": f"{item['category']} chegou a {item['ratio']}% do limite.",
            })
    for bill in account_rows:
        due = date.fromisoformat(bill["due_date"])
        days_left = (due - today).days
        bill_status = "paga" if bill["status"] == "paga" else "atrasada" if days_left < 0 else "a_vencer"
        if bill_status == "atrasada" or (bill_status == "a_vencer" and 0 <= days_left <= 5):
            alerts.append({
                "level": "danger" if bill_status == "atrasada" else "warning",
                "text": f"{bill['name']} vence em {days_left} dia(s)." if days_left >= 0 else f"{bill['name']} está vencida.",
            })
    alerts = alerts[:5]

    comparison = {
        "income_percent": round((income - comparison_income) / comparison_income * 100) if comparison_income else None,
        "expense_percent": round((expenses - comparison_expenses) / comparison_expenses * 100) if comparison_expenses else None,
    }
    recent = sorted(transactions, key=lambda item: (item["date"], item["id"]), reverse=True)[:8]
    return {
        "period": period,
        "period_label": label,
        "comparison_label": comparison_label,
        "balance_cents": balance,
        "income_cents": income,
        "expense_cents": expenses,
        "budget_total_cents": budget_total,
        "budget_spent_cents": budget_spent,
        "budget_remaining_cents": budget_remaining,
        "comparison": comparison,
        "budgets": budget_rows,
        "categories": [{"category": key, "amount_cents": value} for key, value in category_rows],
        "months": months,
        "alerts": alerts,
        "recent_transactions": recent,
        "transaction_count": len(transactions),
        "pending_count": sum(1 for item in transactions if item["status"] == "pendente"),
        "updated_at": today.isoformat(),
    }


def reserve_target(expenses_cents: Any, months: Any) -> dict[str, int]:
    expenses = _integer(expenses_cents, "despesa essencial mensal", minimum=1)
    month_count = _integer(months, "quantidade de meses", minimum=1, maximum=36)
    return {"monthly_expenses_cents": expenses, "months": month_count, "target_cents": expenses * month_count}


def format_cents(value: int) -> str:
    return _cents_label(value)
