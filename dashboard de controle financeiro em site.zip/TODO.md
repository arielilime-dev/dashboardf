# TODO — FinFlow

## Painel de visão geral
- [x] Implementar uma homepage em português brasileiro que ajude a responder “qual é minha situação financeira?” e “o que merece atenção agora?”, com seletor de período e data de atualização.
- [x] Exibir saldo, receitas, despesas, valor ainda disponível no orçamento, comparação com o período anterior e contas a vencer, com explicações/contexto e dados iniciais fictícios identificados como demonstração.
- [x] Mostrar gráfico mensal de receitas versus despesas, gastos por categoria, alertas acionáveis, movimentações recentes e progresso de metas; cálculos e valores dos gráficos devem derivar das mesmas movimentações, não de números decorativos.
- [x] Comunicar alertas de orçamento e vencimentos por texto e estado além de cor; identificar valores futuros de contas como estimativas do usuário, distinguir receitas/despesas confirmadas, movimentações pendentes e itens sem categoria.

## Movimentações e ferramentas financeiras
- [x] Disponibilizar página de movimentações com cadastro, edição, exclusão, busca e filtros por tipo, categoria e status; validar valores e datas e distinguir movimentações pendentes de confirmadas.
- [x] Oferecer exportação CSV das movimentações e exportação/restauração JSON de backup local; solicitar confirmação para excluir registros ou substituir backup.
- [x] Implementar orçamento com limites editáveis por categoria e estado textual de consumo; mostrar excedentes sem ocultar ou falsear valores.
- [x] Implementar contas e cartões com vencimentos e status; derivar atraso da data; ao marcar pagamento local, perguntar explicitamente se deve registrar também o total como despesa, sem duplicar compras já lançadas individualmente.
- [x] Implementar metas com progresso e contribuições locais editáveis, sem alegar que o site moveu dinheiro de verdade.
- [x] Implementar relatórios mensais e por categoria derivados dos mesmos dados salvos no navegador.
- [x] Incluir calculadora de reserva baseada nas despesas essenciais informadas e na quantidade de meses escolhida.

## Área Aprenda e descoberta de conteúdo
- [x] Disponibilizar sete categorias editoriais: Organização financeira; Dívidas e crédito; Economia no dia a dia; Reserva e metas; Investimentos para iniciantes; Renda e carreira; Ferramentas.
- [x] Organizar conteúdos por objetivo e permitir busca, filtro por categoria/nível e descoberta por tags.
- [x] Exibir artigos renderizados no servidor com título claro, resumo, categoria, tempo estimado de leitura, data de atualização, breadcrumbs, índice quando necessário, seções descritivas, exemplos ilustrativos, próximo passo, perguntas frequentes, conteúdos relacionados e referências quando aplicável.
- [x] Interligar artigos a ferramentas e ações relevantes e fornecer busca/navegação que facilite leitura e descoberta.
- [x] Manter conteúdo financeiro sem alegações não verificadas sobre taxas, legislação ou rentabilidade atuais; marcar exemplos como ilustrativos.

## Python, privacidade, acessibilidade e interface
- [x] Implementar o site em Python/Flask com páginas HTML renderizadas por Jinja; usar HTML, CSS e JavaScript para interações e gráficos de barras acessíveis e responsivos, sem bundler ou backend Node.
- [x] Armazenar alterações financeiras apenas no navegador do usuário; o servidor valida e calcula valores enviados sem persistir dados pessoais. Não adicionar login, sincronização, conexão bancária ou falsa persistência nesta versão.
- [x] Identificar dados fictícios e alertar que o armazenamento é local; habilitar ocultar valores. Não exibir informações pessoais ou financeiras no conteúdo público.
- [x] Disponibilizar navegação lateral em desktop e navegação móvel acessível, formulários com feedback, navegação por teclado e respeito a `prefers-reduced-motion`.
- [x] Padronizar moeda em reais e evitar depender somente de cores para transmitir estados.
- [x] Renderizar conteúdo editorial com metadados por página e HTML significativo no carregamento inicial; páginas financeiras recebem `noindex` e `Cache-Control: private, no-store`; canonical/Open Graph absolutos somente quando uma origem pública explícita existir.
- [x] Declarar as rotas públicas de página em `manus-routes.json`, incluindo o padrão de artigo, e manter o arquivo sincronizado com as rotas efetivas.

## Execução e entrega
- [x] Fixar dependências Python em `requirements.txt`, documentar execução e funcionamento local, iniciar Flask em `PORT` (padrão 3000), fornecer health check público `/api/health` e criar `Dockerfile` de produção com Gunicorn.
- [x] Criar identidade FinFlow simples com palavra-marca e símbolo SVG geométrico original, incluindo favicon; usar verde-menta `#1A9E75`, superfícies claras e tipografia legível, com estados em texto além de cor.
- [x] Criar testes de cálculos monetários em centavos, validação, endpoints, status HTTP e rotas; manter registro de diagnóstico Python e HTML/CSS onde suportado.
- [ ] Salvar checkpoint no repositório Manus após as verificações; não publicar o site sem uma solicitação explícita.
