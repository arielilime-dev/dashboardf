"""Aplicação Flask do FinFlow. Dados enviados ao servidor não são persistidos."""
from __future__ import annotations

from datetime import date
from pathlib import Path

from flask import Flask, abort, jsonify, make_response, render_template, request

from content.articles import ARTICLE_BY_SLUG, ARTICLES, CATEGORIES
from finance.calculations import FinanceInputError, calculate_summary, format_cents, reserve_target

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config.update(MAX_CONTENT_LENGTH=1_048_576, TEMPLATES_AUTO_RELOAD=True)
MONTHS_PT = ("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")


def _month_shift(day: date, amount: int) -> date:
    index = day.year * 12 + day.month - 1 + amount
    year, month_zero = divmod(index, 12)
    return date(year, month_zero + 1, 1)


def demo_data() -> dict:
    today = date.today()
    month_start = today.replace(day=1)
    transactions = []
    category_spend = {
        "Moradia": 2_100_00,
        "Alimentação": 860_00,
        "Transporte": 280_00,
        "Saúde": 190_00,
        "Lazer": 390_00,
        "Contas da casa": 420_00,
        "Assinaturas": 74_00,
        "Outros": 162_00,
    }
    budgets = [
        {"category": "Moradia", "limit_cents": 2_400_00},
        {"category": "Alimentação", "limit_cents": 1_100_00},
        {"category": "Transporte", "limit_cents": 400_00},
        {"category": "Saúde", "limit_cents": 300_00},
        {"category": "Lazer", "limit_cents": 500_00},
        {"category": "Contas da casa", "limit_cents": 550_00},
        {"category": "Assinaturas", "limit_cents": 120_00},
        {"category": "Outros", "limit_cents": 300_00},
    ]
    # Histórico demonstrativo: os últimos cinco meses são completos; o atual vai até hoje.
    for offset in range(-5, 1):
        month = _month_shift(month_start, offset)
        year, month_number = month.year, month.month
        income_day = min(2, date(year, month_number, 1).replace(day=1).day + 1)
        cap = today.day if offset == 0 else 28
        transactions.append({
            "id": f"demo-salary-{year}-{month_number}", "date": date(year, month_number, min(income_day, cap)).isoformat(),
            "description": "Salário", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 5_800_00,
        })
        if offset in (-3, -1, 0):
            transactions.append({
                "id": f"demo-extra-{year}-{month_number}", "date": date(year, month_number, min(4, cap)).isoformat(),
                "description": "Projeto freelance", "category": "Renda extra", "type": "receita", "status": "confirmada", "amount_cents": 600_00,
            })
        for number, (category, amount) in enumerate(category_spend.items()):
            day_number = min(number + 2, cap)
            transactions.append({
                "id": f"demo-{year}-{month_number}-{number}", "date": date(year, month_number, day_number).isoformat(),
                "description": {
                    "Moradia": "Aluguel", "Alimentação": "Mercado da semana", "Transporte": "Transporte",
                    "Saúde": "Farmácia", "Lazer": "Cinema e lazer", "Contas da casa": "Conta de energia",
                    "Assinaturas": "Serviços digitais", "Outros": "Compras diversas",
                }[category],
                "category": category, "type": "despesa", "status": "confirmada", "amount_cents": amount,
            })
        if offset == 0:
            transactions.append({
                "id": f"demo-pending-{year}-{month_number}", "date": today.isoformat(),
                "description": "Compra aguardando confirmação", "category": "Sem categoria", "type": "despesa",
                "status": "pendente", "amount_cents": 45_00,
            })

    next_month = _month_shift(month_start, 1)
    bills = [
        {"id": "bill-internet", "name": "Internet", "category": "Contas da casa", "due_date": date(next_month.year, next_month.month, 5).isoformat(), "status": "a_vencer", "amount_cents": 129_90, "transaction_id": ""},
        {"id": "bill-card", "name": "Fatura do cartão", "category": "Cartão", "due_date": date(next_month.year, next_month.month, 8).isoformat(), "status": "a_vencer", "amount_cents": 780_00, "transaction_id": ""},
        {"id": "bill-mobile", "name": "Plano de celular", "category": "Contas da casa", "due_date": date(next_month.year, next_month.month, 12).isoformat(), "status": "a_vencer", "amount_cents": 59_90, "transaction_id": ""},
    ]
    return {
        "initial_balance_cents": 3_500_00,
        "transactions": transactions,
        "budgets": budgets,
        "bills": bills,
        "goals": [
            {"id": "goal-reserve", "name": "Reserva de emergência", "target_cents": 12_000_00, "current_cents": 6_400_00, "monthly_cents": 400_00},
            {"id": "goal-trip", "name": "Viagem", "target_cents": 4_500_00, "current_cents": 1_800_00, "monthly_cents": 250_00},
        ],
    }


def page_context(active: str, title: str, subtitle: str, *, description: str | None = None, robots: str = "noindex,nofollow") -> dict:
    data = demo_data()
    summary = calculate_summary(data)
    return {
        "active": active,
        "page_title": title,
        "page_subtitle": subtitle,
        "meta_description": description or subtitle,
        "robots": robots,
        "today": date.today(),
        "month_label": f"{MONTHS_PT[date.today().month - 1].capitalize()} de {date.today().year}",
        "initial_data": data,
        "summary": summary,
        "format_money": format_cents,
    }


@app.after_request
def no_store_sensitive_pages(response):
    response.headers["Cache-Control"] = "private, no-store, max-age=0"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response


@app.get("/")
def dashboard():
    context = page_context("inicio", "Visão geral", "Seu dinheiro, com mais clareza.")
    context["recent_articles"] = ARTICLES[:3]
    return render_template("dashboard.html", **context)


@app.get("/movimentacoes")
def movements():
    context = page_context("movimentacoes", "Movimentações", "Acompanhe entradas, despesas e pendências.")
    return render_template("movimentacoes.html", **context)


@app.get("/orcamento")
def budget():
    context = page_context("orcamento", "Orçamento", "Planejado e realizado, categoria por categoria.")
    return render_template("orcamento.html", **context)


@app.get("/contas")
def bills():
    context = page_context("contas", "Contas e cartões", "Datas de vencimento e compromissos próximos.")
    return render_template("contas.html", **context)


@app.get("/metas")
def goals():
    context = page_context("metas", "Metas", "Objetivos claros, no ritmo que cabe na sua rotina.")
    return render_template("metas.html", **context)


@app.get("/relatorios")
def reports():
    context = page_context("relatorios", "Relatórios", "Veja como as movimentações se distribuem ao longo do tempo.")
    return render_template("relatorios.html", **context)


@app.get("/aprenda")
def learn():
    query = request.args.get("q", "")[:100].strip()
    context = page_context("aprenda", "Aprenda", "Guias práticos para organizar decisões financeiras.", robots="index,follow")
    context.update(categories=CATEGORIES, articles=ARTICLES, levels=sorted({item["level"] for item in ARTICLES}), query=query)
    return render_template("aprenda.html", **context)


@app.get("/artigos/<slug>")
def article(slug: str):
    item = ARTICLE_BY_SLUG.get(slug)
    if not item:
        abort(404)
    context = page_context("aprenda", item["title"], item["summary"], description=item["summary"], robots="index,follow")
    context["og_type"] = "article"
    context["article"] = item
    context["related_articles"] = [ARTICLE_BY_SLUG[key] for key in item["related"] if key in ARTICLE_BY_SLUG]
    return render_template("artigo.html", **context)


@app.get("/manus-routes.json")
def route_manifest():
    manifest = Path(app.root_path, "public", "manus-routes.json").read_text(encoding="utf-8")
    return app.response_class(manifest, mimetype="application/json")


@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "finflow-python"})


@app.post("/api/resumo")
def api_summary():
    payload = request.get_json(silent=True) or {}
    try:
        result = calculate_summary(payload.get("data"), period=payload.get("period", "current"))
    except FinanceInputError as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify(result)


@app.post("/api/reserva")
def api_reserve():
    payload = request.get_json(silent=True) or {}
    try:
        result = reserve_target(payload.get("expenses_cents"), payload.get("months"))
    except FinanceInputError as exc:
        return jsonify({"error": str(exc)}), 400
    return jsonify(result)


@app.errorhandler(FinanceInputError)
def invalid_finance_input(error):
    return jsonify({"error": str(error)}), 400


@app.errorhandler(413)
def oversized_request(_error):
    return jsonify({"error": "O arquivo ou envio excede o limite de 1 MB."}), 413


@app.errorhandler(404)
def not_found(_error):
    context = page_context("", "Página não encontrada", "O endereço não existe ou o conteúdo foi removido.")
    response = make_response(render_template("404.html", **context), 404)
    response.headers["X-Robots-Tag"] = "noindex"
    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(__import__("os").environ.get("PORT", "3000")), debug=False)
