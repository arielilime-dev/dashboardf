"""Regras e cálculos financeiros do FinFlow."""
