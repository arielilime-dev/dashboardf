import unittest
from datetime import date

from app import app, demo_data
from finance.calculations import FinanceInputError, calculate_summary, reserve_target, validate_data


class FinanceCalculationTests(unittest.TestCase):
    def test_pending_transactions_do_not_change_balance_or_expenses(self):
        sample = {
            "initial_balance_cents": 100_00,
            "transactions": [
                {"id": "income", "date": date.today().isoformat(), "description": "Pagamento", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 250_00},
                {"id": "pending", "date": date.today().isoformat(), "description": "Aguardando", "category": "Outros", "type": "despesa", "status": "pendente", "amount_cents": 80_00},
            ],
            "budgets": [{"category": "Outros", "limit_cents": 200_00}],
            "bills": [], "goals": [],
        }
        result = calculate_summary(sample, today=date.today())
        self.assertEqual(result["balance_cents"], 350_00)
        self.assertEqual(result["expense_cents"], 0)
        self.assertEqual(result["pending_count"], 1)

    def test_confirmed_expense_changes_category_and_budget(self):
        sample = {
            "initial_balance_cents": 0,
            "transactions": [{"id": "x", "date": date.today().isoformat(), "description": "Mercado", "category": "Alimentação", "type": "despesa", "status": "confirmada", "amount_cents": 12_345}],
            "budgets": [{"category": "Alimentação", "limit_cents": 20_000}],
            "bills": [], "goals": [],
        }
        result = calculate_summary(sample, today=date.today())
        self.assertEqual(result["expense_cents"], 12_345)
        self.assertEqual(result["budget_remaining_cents"], 7_655)
        self.assertEqual(result["categories"][0]["amount_cents"], 12_345)

    def test_reserve_calculation_uses_integer_cents(self):
        self.assertEqual(reserve_target(250_050, 3)["target_cents"], 750_150)

    def test_selected_month_compares_with_the_month_before_it(self):
        sample = {
            "initial_balance_cents": 0,
            "transactions": [
                {"id": "oct-income", "date": "2026-10-03", "description": "Outubro", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 20_000},
                {"id": "sep-income", "date": "2026-09-03", "description": "Setembro", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 10_000},
                {"id": "oct-expense", "date": "2026-10-04", "description": "Outubro", "category": "Outros", "type": "despesa", "status": "confirmada", "amount_cents": 1_000},
                {"id": "sep-expense", "date": "2026-09-04", "description": "Setembro", "category": "Outros", "type": "despesa", "status": "confirmada", "amount_cents": 2_000},
            ],
            "budgets": [], "bills": [], "goals": [],
        }
        result = calculate_summary(sample, today=date(2026, 11, 4), period="previous")
        self.assertEqual(result["period_label"], "Outubro de 2026")
        self.assertEqual(result["comparison"]["income_percent"], 100)
        self.assertEqual(result["comparison"]["expense_percent"], -50)
        history = calculate_summary(sample, today=date(2026, 11, 4), period="six_months")
        self.assertIsNone(history["comparison"]["income_percent"])

    def test_current_period_compares_the_same_elapsed_days(self):
        sample = {
            "initial_balance_cents": 0,
            "transactions": [
                {"id": "nov", "date": "2026-11-03", "description": "Atual", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 10_000},
                {"id": "oct-in-range", "date": "2026-10-03", "description": "Mesmo período", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 5_000},
                {"id": "oct-out-of-range", "date": "2026-10-05", "description": "Depois do corte", "category": "Renda", "type": "receita", "status": "confirmada", "amount_cents": 45_000},
            ],
            "budgets": [], "bills": [], "goals": [],
        }
        result = calculate_summary(sample, today=date(2026, 11, 4), period="current")
        self.assertEqual(result["comparison"]["income_percent"], 100)
        self.assertIn("mesmos dias", result["comparison_label"])

    def test_category_totals_follow_selected_period(self):
        sample = {
            "initial_balance_cents": 0,
            "transactions": [
                {"id": "nov", "date": "2026-11-10", "description": "Atual", "category": "Novembro", "type": "despesa", "status": "confirmada", "amount_cents": 5_000},
                {"id": "oct", "date": "2026-10-10", "description": "Anterior", "category": "Outubro", "type": "despesa", "status": "confirmada", "amount_cents": 20_000},
                {"id": "sep", "date": "2026-09-10", "description": "Histórico", "category": "Setembro", "type": "despesa", "status": "confirmada", "amount_cents": 10_000},
            ],
            "budgets": [], "bills": [], "goals": [],
        }
        previous = calculate_summary(sample, today=date(2026, 11, 15), period="previous")
        self.assertEqual(previous["expense_cents"], sum(item["amount_cents"] for item in previous["categories"]))
        self.assertEqual(previous["categories"], [{"category": "Outubro", "amount_cents": 20_000}])
        history = calculate_summary(sample, today=date(2026, 11, 15), period="six_months")
        self.assertEqual(history["expense_cents"], sum(item["amount_cents"] for item in history["categories"]))

    def test_past_due_bill_is_detected_from_date(self):
        sample = {
            "initial_balance_cents": 0, "transactions": [], "budgets": [], "goals": [],
            "bills": [{"id": "rent", "name": "Aluguel", "category": "Moradia", "due_date": "2026-11-03", "status": "a_vencer", "amount_cents": 100_000, "transaction_id": ""}],
        }
        result = calculate_summary(sample, today=date(2026, 11, 4))
        self.assertTrue(any(alert["level"] == "danger" and "Aluguel está vencida" in alert["text"] for alert in result["alerts"]))

    def test_rejects_invalid_dates_and_values(self):
        with self.assertRaises(FinanceInputError):
            reserve_target(2_000, 37)
        with self.assertRaises(FinanceInputError):
            validate_data({"transactions": [{"id": "bad", "date": "04/11/2026", "description": "x", "category": "Outros", "type": "despesa", "status": "confirmada", "amount_cents": 100}]})

    def test_demo_data_has_all_expected_collections(self):
        data = validate_data(demo_data())
        self.assertGreater(len(data["transactions"]), 8)
        self.assertGreater(len(data["budgets"]), 0)
        self.assertGreater(len(data["goals"]), 0)


class FlaskRouteTests(unittest.TestCase):
    def setUp(self):
        app.testing = True
        self.client = app.test_client()

    def test_dashboard_and_finance_pages_render(self):
        for path in ("/", "/movimentacoes", "/orcamento", "/contas", "/metas", "/relatorios"):
            with self.subTest(path=path):
                response = self.client.get(path)
                self.assertEqual(response.status_code, 200)
                self.assertIn("FinFlow", response.get_data(as_text=True))
                self.assertIn("private, no-store", response.headers["Cache-Control"])
        dashboard = self.client.get("/").get_data(as_text=True)
        self.assertIn("data-dashboard-goals", dashboard)
        self.assertIn("Reserva de emergência", dashboard)
        learn = self.client.get("/aprenda").get_data(as_text=True)
        self.assertIn("data-level-filter", learn)
        self.assertIn("Todos os níveis", learn)
        self.assertIn("data-objective-query", learn)
        self.assertIn("Organizar meu mês", learn)

    def test_articles_are_server_rendered_and_unknown_slugs_return_404(self):
        response = self.client.get("/artigos/orcamento-mensal-em-5-etapas")
        self.assertEqual(response.status_code, 200)
        self.assertIn("Como montar um orçamento mensal", response.get_data(as_text=True))
        self.assertIn('name="robots" content="index,follow"', response.get_data(as_text=True))
        self.assertEqual(self.client.get("/artigos/nao-existe").status_code, 404)

    def test_routes_manifest_is_json_not_spa_fallback(self):
        response = self.client.get("/manus-routes.json")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.mimetype, "application/json")
        self.assertIn("/artigos/:slug", response.get_json()["routes"][-1]["path"])

    def test_health_and_summary_endpoints(self):
        self.assertEqual(self.client.get("/api/health").get_json()["status"], "ok")
        response = self.client.post("/api/resumo", json={"data": demo_data(), "period": "current"})
        self.assertEqual(response.status_code, 200)
        self.assertGreater(response.get_json()["balance_cents"], 0)

    def test_summary_rejects_invalid_payload_and_does_not_persist(self):
        bad = {"data": {"transactions": [], "budgets": [], "bills": [], "goals": [], "initial_balance_cents": "100"}}
        response = self.client.post("/api/resumo", json=bad)
        self.assertEqual(response.status_code, 400)
        health = self.client.get("/api/health")
        self.assertEqual(health.status_code, 200)

    def test_reserve_endpoint(self):
        response = self.client.post("/api/reserva", json={"expenses_cents": 200_000, "months": 6})
        self.assertEqual(response.get_json()["target_cents"], 1_200_000)
        self.assertEqual(self.client.post("/api/reserva", json={"expenses_cents": 200_000, "months": 40}).status_code, 400)


if __name__ == "__main__":
    unittest.main()
