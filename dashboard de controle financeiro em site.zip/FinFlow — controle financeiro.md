# FinFlow — controle financeiro

Site em Flask para acompanhar registros de receitas, despesas, orçamento, contas, metas e relatórios, com uma área educativa de guias financeiros.

## Privacidade e limites

A primeira visita usa dados fictícios de demonstração. Registros adicionados pelo usuário ficam no `localStorage` do navegador. O backend recebe o estado somente enquanto calcula os resumos ou a meta de reserva; não o grava em arquivo, sessão, banco de dados ou log de aplicação. O site não tem login, sincronização, conexão bancária nem pagamento. O armazenamento do navegador não é um backup: use os controles de exportação JSON para manter uma cópia. As páginas explicam essas limitações.

Ao marcar uma conta ou fatura como paga, a interface pergunta separadamente se o total deve virar uma nova despesa. Se compras do cartão já foram registradas uma a uma, escolha não registrar novamente a fatura.

Os artigos são educativos, usam exemplos ilustrativos e não constituem recomendação financeira individual. Confira regras atuais em fontes oficiais.

## Executar localmente

Requer Python 3.12 ou mais recente. Crie e ative um ambiente virtual e instale as dependências:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py
```

O app escuta em `0.0.0.0:$PORT`, usando a porta 3000 se `PORT` não estiver definida. A verificação de saúde está em `/api/health`.

## Testes

```bash
python -m unittest discover -s tests -v
```

Os testes usam o cliente Flask e não fazem gravações em serviço externo. A estrutura não contém banco de dados.

## Rotas principais

- `/` — visão geral.
- `/movimentacoes` — registros, filtros e exportação/importação local.
- `/orcamento` — limites por categoria.
- `/contas` — vencimentos e status.
- `/metas` — objetivos e calculadora de reserva.
- `/relatorios` — fluxo e composição por categoria.
- `/aprenda` — busca e descoberta de guias.
- `/artigos/<slug>` — conteúdo educativo renderizado no servidor.
- `/api/health`, `/api/resumo` e `/api/reserva` — endpoints do servidor Python.
- `/manus-routes.json` — manifesto de páginas do site.

## Container

O `Dockerfile` instala as dependências fixadas, inicia Gunicorn e respeita a variável `PORT` fornecida no runtime.
