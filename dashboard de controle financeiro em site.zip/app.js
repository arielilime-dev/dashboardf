(() => {
  "use strict";
  const STORE_KEY = "finflow:v1";
  const initial = window.FINFLOW_INITIAL_DATA;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
  const dateFormatter = new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
  let toastTimer;

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function readStore() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORE_KEY));
      if (saved && Array.isArray(saved.transactions) && Array.isArray(saved.budgets) && Array.isArray(saved.bills) && Array.isArray(saved.goals)) return saved;
    } catch (_) { /* conteúdo local inválido será substituído pela amostra segura */ }
    const seeded = clone(initial);
    try { localStorage.setItem(STORE_KEY, JSON.stringify(seeded)); } catch (_) { showToast("Não foi possível acessar o armazenamento local.", true); }
    return seeded;
  }
  let state = readStore();

  function centsFromInput(value) {
    const parsed = Number(String(value).replace(",", "."));
    if (!Number.isFinite(parsed) || parsed <= 0 || parsed > 1_000_000_000) return null;
    return Math.round(parsed * 100);
  }
  function moneyText(cents) { return money.format((Number(cents) || 0) / 100); }
  function dateText(iso) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso || "")) return iso || "";
    const [year, month, day] = iso.split("-").map(Number);
    return dateFormatter.format(new Date(year, month - 1, day, 12));
  }
  function localIsoDate() {
    const today = new Date();
    today.setMinutes(today.getMinutes() - today.getTimezoneOffset());
    return today.toISOString().slice(0, 10);
  }
  function effectiveBillStatus(bill) {
    if (bill.status === "paga") return "paga";
    return bill.due_date < localIsoDate() ? "atrasada" : "a_vencer";
  }
  function escapeCsv(value) {
    let text = String(value ?? "");
    if (/^[=+@\-]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  }
  function showToast(message, isError = false) {
    const toast = $(`[data-toast]`);
    if (!toast) return;
    toast.textContent = message;
    toast.classList.toggle("is-error", isError);
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2800);
  }
  function saveStore(message = "Alterações salvas neste navegador.") {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(state));
      showToast(message);
      refreshSummary();
    } catch (_) {
      showToast("O navegador não conseguiu salvar. Exporte um backup e libere espaço.", true);
    }
  }
  async function postJson(url, body) {
    const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Não foi possível calcular esses dados.");
    return result;
  }
  function setText(selector, text) { $$(selector).forEach((node) => { node.textContent = text; }); }
  function currentPeriod() { return $(`[data-period]`)?.value || "current"; }

  async function refreshSummary() {
    try {
      const summary = await postJson("/api/resumo", { data: state, period: currentPeriod() });
      updateSummary(summary);
    } catch (error) {
      showToast(error.message || "Erro ao atualizar o painel.", true);
    }
  }
  function updateSummary(summary) {
    ["balance_cents", "income_cents", "expense_cents", "budget_remaining_cents"].forEach((key) => {
      setText(`[data-value="${key}"]`, moneyText(summary[key]));
    });
    setText("[data-transaction-count]", String(summary.transaction_count));
    setText("[data-pending-count]", String(summary.pending_count));
    setText("[data-budget-total]", moneyText(summary.budget_total_cents));
    setText("[data-budget-spent]", moneyText(summary.budget_spent_cents));
    setText("[data-report-net]", moneyText(summary.income_cents - summary.expense_cents));
    const comparison = summary.comparison || {};
    $$('[data-comparison]').forEach((node) => {
      const key = node.dataset.comparison;
      const value = comparison[`${key}_percent`];
      node.textContent = value === null || value === undefined ? "Sem comparativo anterior" : `Variação de ${value > 0 ? "+" : ""}${value}% ${summary.comparison_label || "em relação ao período anterior"}`;
    });
    const label = $(`[data-period-label]`);
    if (label) label.textContent = summary.period_label;
    const chartDescription = summary.months.map((month) => `${month.label}: receitas ${moneyText(month.income_cents)}; despesas ${moneyText(month.expense_cents)}`).join(". ");
    $$(`[data-chart-summary]`).forEach((node) => { node.textContent = `Valores confirmados por mês, em ${summary.period_label}: ${chartDescription}.`; });
    renderCharts(summary);
    renderBudgetEditor(summary);
    renderRecent(summary.recent_transactions || []);
    renderTransactionTable();
    renderBills();
    renderGoals();
    renderDashboardGoals();
    renderCategoryReport(summary.categories || [], summary.expense_cents);
    renderAlerts(summary.alerts || []);
  }
  function renderCharts(summary) {
    $$(`[data-flow-chart]`).forEach((chart) => {
      chart.replaceChildren();
      chart.setAttribute("aria-label", `Gráfico comparativo de receitas e despesas: ${summary.period_label}.`);
      const max = Math.max(1, ...summary.months.flatMap((month) => [month.income_cents, month.expense_cents]));
      summary.months.forEach((month) => {
        const wrapper = document.createElement("div"); wrapper.className = "flow-month";
        const pair = document.createElement("div"); pair.className = "bar-pair";
        [["income-bar", month.income_cents, "Receitas"], ["expense-bar", month.expense_cents, "Despesas"]].forEach(([className, cents, label]) => {
          const bar = document.createElement("div"); bar.className = `bar ${className}`;
          bar.style.setProperty("--bar-height", `${Math.max(2, Math.round(cents / max * 100))}%`);
          bar.title = `${label}: ${moneyText(cents)}`;
          pair.append(bar);
        });
        const text = document.createElement("span"); text.textContent = month.label;
        wrapper.append(pair, text); chart.append(wrapper);
      });
      const values = chart.parentElement?.querySelectorAll(".chart-baseline [data-value]");
      if (values?.length) values[0].textContent = moneyText(summary.income_cents);
    });
  }
  function budgetState(spent, limit) {
    const ratio = limit ? Math.round(spent / limit * 100) : (spent ? 100 : 0);
    return { ratio, label: spent > limit ? "acima do limite" : ratio >= 80 ? "perto do limite" : "dentro do limite" };
  }
  function renderBudgetEditor(summary) {
    const editor = $(`[data-budget-editor]`);
    if (editor) {
      const existing = new Map(summary.budgets.map((item) => [item.category, item]));
      $$("[data-budget-category]", editor).forEach((row) => {
        const item = existing.get(row.dataset.budgetCategory);
        if (!item) return;
        const stateNode = $(".budget-state", row);
        if (stateNode) { stateNode.textContent = item.state; stateNode.className = `budget-state ${item.ratio >= 100 ? "state-danger" : item.ratio >= 80 ? "state-warning" : ""}`; }
        const spent = $(`[data-spent]`, row); if (spent) spent.textContent = moneyText(item.spent_cents);
        const progress = $(`[data-progress]`, row); if (progress) { progress.style.width = `${Math.min(item.ratio, 100)}%`; progress.className = `progress-fill ${item.ratio >= 100 ? "is-over" : item.ratio >= 80 ? "is-warning" : ""}`; }
        const percent = $(`[data-budget-percent]`, row); if (percent) percent.textContent = `${item.ratio}% do limite`;
      });
    }
    const preview = $(`[data-budget-preview]`);
    if (preview) {
      preview.replaceChildren();
      summary.budgets.slice(0, 5).forEach((item) => {
        const row = document.createElement("div"); row.className = "budget-row";
        const top = document.createElement("div"); top.className = "budget-row-top";
        const category = document.createElement("span"); category.textContent = item.category;
        const amounts = document.createElement("span"); amounts.className = "budget-numbers privacy-value";
        amounts.textContent = `${moneyText(item.spent_cents)} / ${moneyText(item.limit_cents)}`;
        top.append(category, amounts);
        const track = document.createElement("div"); track.className = "progress-track";
        const fill = document.createElement("span"); fill.className = `progress-fill ${item.ratio >= 100 ? "is-over" : item.ratio >= 80 ? "is-warning" : ""}`; fill.style.width = `${Math.min(item.ratio, 100)}%`; track.append(fill);
        const status = document.createElement("span"); status.className = `budget-state ${item.ratio >= 100 ? "state-danger" : item.ratio >= 80 ? "state-warning" : ""}`; status.textContent = item.state;
        row.append(top, track, status); preview.append(row);
      });
    }
  }
  function renderRecent(items) {
    const list = $(`[data-recent-list]`);
    if (!list) return;
    list.replaceChildren();
    items.slice(0, 5).forEach((item) => {
      const row = document.createElement("div"); row.className = "transaction-row";
      const symbol = document.createElement("span"); symbol.className = `transaction-symbol ${item.type === "receita" ? "symbol-income" : "symbol-expense"}`; symbol.textContent = item.type === "receita" ? "↑" : "↘";
      const info = document.createElement("div"); info.className = "transaction-info";
      const title = document.createElement("strong"); title.textContent = item.description;
      const detail = document.createElement("span"); detail.textContent = `${item.category} · ${dateText(item.date)}`; info.append(title, detail);
      const amount = document.createElement("div"); amount.className = `transaction-amount privacy-value ${item.type === "receita" ? "amount-income" : ""}`; amount.textContent = `${item.type === "receita" ? "+" : "−"}${moneyText(item.amount_cents)}`;
      if (item.status === "pendente") { const pending = document.createElement("small"); pending.className = "status-pending"; pending.textContent = "Pendente"; amount.append(pending); }
      row.append(symbol, info, amount); list.append(row);
    });
  }
  function renderAlerts(items) {
    const list = $(`[data-alert-list]`); if (!list) return;
    list.replaceChildren();
    if (!items.length) { const empty = document.createElement("div"); empty.className = "empty-state compact"; const icon = document.createElement("span"); icon.textContent = "✓"; const text = document.createElement("p"); text.textContent = "Tudo em dia por aqui."; empty.append(icon, text); list.append(empty); return; }
    items.forEach((item) => {
      const row = document.createElement("div"); row.className = `alert-item alert-${item.level}`;
      const mark = document.createElement("span"); mark.className = "alert-mark"; mark.textContent = item.level === "danger" ? "!" : "↗";
      const text = document.createElement("p"); text.textContent = item.text;
      const link = document.createElement("a"); link.href = /vence|vencida/i.test(item.text) ? "/contas" : "/orcamento"; link.textContent = "↗"; link.setAttribute("aria-label", "Ver detalhes");
      row.append(mark, text, link); list.append(row);
    });
  }
  function renderTransactionTable() {
    const body = $(`[data-transaction-table]`); if (!body) return;
    const query = ($(`[data-transaction-search]`)?.value || "").trim().toLocaleLowerCase("pt-BR");
    const type = $(`[data-type-filter]`)?.value || "todos";
    const status = $(`[data-status-filter]`)?.value || "todos";
    const categorySelect = $(`[data-category-filter]`);
    const priorCategory = categorySelect?.value || "todos";
    if (categorySelect) {
      const options = [new Option("Todas as categorias", "todos")];
      [...new Set(state.transactions.map((item) => item.category))].sort((a, b) => a.localeCompare(b, "pt-BR")).forEach((category) => options.push(new Option(category, category)));
      categorySelect.replaceChildren(...options);
      categorySelect.value = options.some((option) => option.value === priorCategory) ? priorCategory : "todos";
    }
    const categoryFilter = categorySelect?.value || "todos";
    const items = [...state.transactions].sort((a, b) => b.date.localeCompare(a.date)).filter((item) => {
      const matchesText = `${item.description} ${item.category}`.toLocaleLowerCase("pt-BR").includes(query);
      return matchesText && (type === "todos" || item.type === type) && (categoryFilter === "todos" || item.category === categoryFilter) && (status === "todos" || item.status === status);
    });
    body.replaceChildren();
    items.forEach((item) => {
      const row = document.createElement("tr");
      const descriptionCell = document.createElement("td"); const main = document.createElement("div"); main.className = "table-main-cell";
      const icon = document.createElement("span"); icon.className = `transaction-symbol ${item.type === "receita" ? "symbol-income" : "symbol-expense"}`; icon.textContent = item.type === "receita" ? "↑" : "↘";
      const copy = document.createElement("span"); copy.className = "table-main-copy"; const desc = document.createElement("strong"); desc.textContent = item.description; const typeLabel = document.createElement("small"); typeLabel.textContent = item.type === "receita" ? "Receita" : "Despesa"; copy.append(desc, typeLabel); main.append(icon, copy); descriptionCell.append(main);
      const category = document.createElement("td"); category.textContent = item.category;
      const date = document.createElement("td"); date.textContent = dateText(item.date);
      const statusCell = document.createElement("td"); const statusBadge = document.createElement("span"); statusBadge.className = `table-status ${item.status === "pendente" ? "pending" : ""}`; statusBadge.textContent = item.status === "pendente" ? "Pendente" : "Confirmada"; statusCell.append(statusBadge);
      const amount = document.createElement("td"); amount.className = `align-right privacy-value ${item.type === "receita" ? "amount-income" : ""}`; amount.textContent = `${item.type === "receita" ? "+" : "−"}${moneyText(item.amount_cents)}`;
      const action = document.createElement("td"); const controls = document.createElement("div"); controls.className = "table-row-actions";
      const edit = document.createElement("button"); edit.type = "button"; edit.className = "table-edit"; edit.textContent = "Editar"; edit.dataset.editTransaction = item.id; edit.setAttribute("aria-label", `Editar ${item.description}`);
      const remove = document.createElement("button"); remove.type = "button"; remove.className = "table-delete"; remove.textContent = "×"; remove.title = "Excluir movimentação"; remove.setAttribute("aria-label", `Excluir ${item.description}`); remove.dataset.deleteTransaction = item.id;
      controls.append(edit, remove); action.append(controls);
      row.append(descriptionCell, category, date, statusCell, amount, action); body.append(row);
    });
    const empty = $(`[data-table-empty]`); if (empty) empty.hidden = items.length > 0;
  }
  function renderBills() {
    const list = $(`[data-bill-list]`); if (!list) return;
    list.replaceChildren();
    const bills = [...state.bills].sort((a, b) => a.due_date.localeCompare(b.due_date));
    bills.forEach((bill) => {
      const billStatus = effectiveBillStatus(bill);
      const row = document.createElement("article"); row.className = "bill-row";
      const icon = document.createElement("span"); icon.className = "bill-icon"; icon.textContent = "▤";
      const main = document.createElement("div"); main.className = "bill-main"; const name = document.createElement("strong"); name.textContent = bill.name; const detail = document.createElement("span"); detail.textContent = `${bill.category} · vence em ${dateText(bill.due_date)}`; main.append(name, detail);
      const status = document.createElement("span"); status.className = `bill-status status-${billStatus}`; status.textContent = billStatus === "paga" ? "Paga" : billStatus === "atrasada" ? "Atrasada" : "A vencer";
      const amount = document.createElement("strong"); amount.className = "bill-amount privacy-value"; amount.textContent = moneyText(bill.amount_cents);
      row.append(icon, main, status, amount);
      if (billStatus === "paga") { const paid = document.createElement("span"); paid.className = "bill-paid-label"; paid.textContent = "Concluída"; row.append(paid); }
      else { const button = document.createElement("button"); button.className = "button button-quiet button-small"; button.type = "button"; button.textContent = "Marcar paga"; button.dataset.payBill = bill.id; row.append(button); }
      list.append(row);
    });
    const empty = $(`[data-bills-empty]`); if (empty) empty.hidden = bills.length > 0;
    const count = $(`[data-bill-count]`); if (count) count.textContent = `${bills.filter((bill) => bill.status !== "paga").length} em aberto`;
  }
  function renderGoals() {
    const list = $(`[data-goal-list]`); if (!list) return;
    list.replaceChildren();
    state.goals.forEach((goal) => {
      const progress = Math.min(100, Math.round(goal.current_cents / goal.target_cents * 100));
      const card = document.createElement("article"); card.className = "panel goal-card";
      const top = document.createElement("div"); top.className = "goal-top"; const icon = document.createElement("span"); icon.className = "goal-icon"; icon.textContent = "◎"; const tag = document.createElement("span"); tag.className = "goal-tag"; tag.textContent = "OBJETIVO"; top.append(icon, tag);
      const title = document.createElement("h2"); title.textContent = goal.name;
      const note = document.createElement("p"); note.className = "goal-note"; note.textContent = "Progresso registrado somente neste navegador.";
      const amounts = document.createElement("div"); amounts.className = "goal-amounts"; const current = document.createElement("strong"); current.className = "privacy-value"; current.textContent = moneyText(goal.current_cents); const target = document.createElement("span"); target.innerHTML = "de <span class=\"privacy-value\"></span>"; $("span", target).textContent = moneyText(goal.target_cents); amounts.append(current, target);
      const track = document.createElement("div"); track.className = "progress-track goal-progress"; const fill = document.createElement("span"); fill.className = "progress-fill"; fill.style.width = `${progress}%`; track.append(fill);
      const bottom = document.createElement("div"); bottom.className = "goal-bottom"; const percent = document.createElement("span"); percent.textContent = `${progress}% concluído`; const monthly = document.createElement("span"); monthly.textContent = `Contribuição mensal: ${moneyText(goal.monthly_cents)}`; bottom.append(percent, monthly);
      const form = document.createElement("form"); form.className = "goal-contribute"; form.dataset.goalForm = goal.id;
      const label = document.createElement("label"); label.textContent = "Registrar contribuição (R$)"; const input = document.createElement("input"); input.type = "number"; input.step = "0.01"; input.min = "0.01"; input.required = true; input.placeholder = "0,00"; label.append(input); const button = document.createElement("button"); button.className = "button button-quiet button-small"; button.type = "submit"; button.textContent = "Adicionar"; form.append(label, button);
      card.append(top, title, note, amounts, track, bottom, form); list.append(card);
    });
  }
  function renderDashboardGoals() {
    const list = $(`[data-dashboard-goals]`); if (!list) return;
    list.replaceChildren();
    state.goals.slice(0, 3).forEach((goal) => {
      const progress = Math.min(100, Math.round(goal.current_cents / goal.target_cents * 100));
      const card = document.createElement("article"); card.className = "goal-overview-item";
      const heading = document.createElement("div"); heading.className = "goal-overview-heading";
      const name = document.createElement("strong"); name.textContent = goal.name;
      const percent = document.createElement("span"); percent.textContent = `${progress}% concluído`; heading.append(name, percent);
      const amounts = document.createElement("div"); amounts.className = "goal-overview-amounts";
      const current = document.createElement("strong"); current.className = "privacy-value"; current.textContent = moneyText(goal.current_cents);
      const target = document.createElement("span"); target.innerHTML = 'de <span class="privacy-value"></span>'; $("span", target).textContent = moneyText(goal.target_cents); amounts.append(current, target);
      const track = document.createElement("div"); track.className = "progress-track goal-overview-track"; track.setAttribute("role", "progressbar"); track.setAttribute("aria-label", `Progresso de ${goal.name}`); track.setAttribute("aria-valuemin", "0"); track.setAttribute("aria-valuemax", "100"); track.setAttribute("aria-valuenow", String(progress));
      const fill = document.createElement("span"); fill.className = "progress-fill"; fill.style.width = `${progress}%`; track.append(fill);
      card.append(heading, amounts, track); list.append(card);
    });
    if (!state.goals.length) { const empty = document.createElement("p"); empty.className = "goal-overview-empty"; empty.textContent = "Crie uma meta para acompanhar o progresso por aqui."; list.append(empty); }
  }
  function renderCategoryReport(items, total) {
    const container = $(`[data-category-report]`); if (!container) return;
    container.replaceChildren();
    if (!items.length) { const empty = document.createElement("div"); empty.className = "empty-state"; const icon = document.createElement("span"); icon.textContent = "↗"; const p = document.createElement("p"); p.textContent = "Registre despesas para ver uma análise por categoria."; empty.append(icon, p); container.append(empty); return; }
    items.forEach((item) => {
      const ratio = total ? Math.round(item.amount_cents / total * 100) : 0;
      const row = document.createElement("div"); row.className = "category-report-row";
      const top = document.createElement("div"); const category = document.createElement("span"); category.textContent = item.category; const amount = document.createElement("strong"); amount.className = "privacy-value"; amount.textContent = moneyText(item.amount_cents); top.append(category, amount);
      const track = document.createElement("div"); track.className = "progress-track"; const fill = document.createElement("span"); fill.className = "progress-fill"; fill.style.width = `${ratio}%`; track.append(fill);
      const detail = document.createElement("small"); detail.textContent = `${ratio}% das despesas no período`; row.append(top, track, detail); container.append(row);
    });
  }

  $$(`[data-open-movement]`).forEach((button) => button.addEventListener("click", () => {
    const dialog = $("#movement-dialog"); const form = $(`[data-movement-form]`);
    if (form) { form.reset(); delete form.dataset.editId; form.elements.date.value = localIsoDate(); }
    const title = $("#movement-dialog-title"); if (title) title.textContent = "Nova movimentação";
    const submitButton = $(`[data-movement-submit]`); if (submitButton) submitButton.textContent = "Salvar movimentação";
    dialog?.showModal();
  }));
  $(`[data-close-dialog]`)?.addEventListener("click", () => $("#movement-dialog")?.close());
  $(`[data-movement-form]`)?.addEventListener("submit", (event) => {
    event.preventDefault(); const form = event.currentTarget; const amount = centsFromInput(form.elements.amount.value);
    if (!amount) { showToast("Informe um valor maior que zero.", true); return; }
    const editingId = form.dataset.editId;
    if (editingId && !state.transactions.some((item) => item.id === editingId)) { showToast("A movimentação não está mais disponível para edição.", true); return; }
    const entry = { id: editingId || crypto.randomUUID?.() || `mov-${Date.now()}`, date: form.elements.date.value, description: form.elements.description.value.trim(), category: form.elements.category.value || "Sem categoria", type: form.elements.type.value, status: form.elements.pending.checked ? "pendente" : "confirmada", amount_cents: amount };
    if (editingId) state.transactions = state.transactions.map((item) => item.id === editingId ? entry : item);
    else state.transactions.push(entry);
    delete form.dataset.editId; form.reset(); $("#movement-dialog-title").textContent = "Nova movimentação"; $(`[data-movement-submit]`).textContent = "Salvar movimentação"; $("#movement-dialog")?.close(); renderTransactionTable();
    saveStore(editingId ? "Movimentação atualizada neste navegador." : "Movimentação adicionada neste navegador.");
  });

  $(`[data-transaction-search]`)?.addEventListener("input", renderTransactionTable);
  $(`[data-type-filter]`)?.addEventListener("change", renderTransactionTable);
  $(`[data-category-filter]`)?.addEventListener("change", renderTransactionTable);
  $(`[data-status-filter]`)?.addEventListener("change", renderTransactionTable);
  $(`[data-transaction-table]`)?.addEventListener("click", (event) => {
    const editButton = event.target.closest("[data-edit-transaction]");
    if (editButton) {
      const item = state.transactions.find((entry) => entry.id === editButton.dataset.editTransaction);
      const form = $(`[data-movement-form]`); if (!item || !form) return;
      form.elements.date.value = item.date; form.elements.description.value = item.description; form.elements.amount.value = (item.amount_cents / 100).toFixed(2); form.elements.type.value = item.type; form.elements.pending.checked = item.status === "pendente";
      const category = form.elements.category;
      if (![...category.options].some((option) => option.value === item.category)) { const option = document.createElement("option"); option.value = item.category; option.textContent = item.category; category.add(option); }
      category.value = item.category; form.dataset.editId = item.id;
      const title = $("#movement-dialog-title"); if (title) title.textContent = "Editar movimentação";
      const submitButton = $(`[data-movement-submit]`); if (submitButton) submitButton.textContent = "Salvar alterações";
      $("#movement-dialog")?.showModal(); return;
    }
    const button = event.target.closest("[data-delete-transaction]"); if (!button) return;
    const item = state.transactions.find((entry) => entry.id === button.dataset.deleteTransaction);
    if (!item || !window.confirm(`Excluir a movimentação “${item.description}”?`)) return;
    state.transactions = state.transactions.filter((entry) => entry.id !== item.id); saveStore("Movimentação excluída.");
  });
  $(`[data-budget-form]`)?.addEventListener("submit", (event) => {
    event.preventDefault();
    for (const input of $$(`[data-budget-input]`)) {
      const cents = input.value.trim() === "" ? 0 : Math.round(Number(input.value) * 100);
      if (!Number.isSafeInteger(cents) || cents < 0 || cents > 100_000_000_000) { showToast("Confira os limites informados.", true); return; }
      const budget = state.budgets.find((item) => item.category === input.dataset.budgetInput);
      if (budget) budget.limit_cents = cents;
    }
    saveStore("Limites do orçamento atualizados.");
  });

  function createSimpleDialog(title, fields, submitLabel, onSubmit) {
    const dialog = document.createElement("dialog"); dialog.className = "movement-dialog";
    const close = document.createElement("form"); close.method = "dialog"; close.className = "dialog-close-form"; const closeButton = document.createElement("button"); closeButton.className = "icon-button"; closeButton.setAttribute("aria-label", "Fechar"); closeButton.textContent = "×"; close.append(closeButton);
    const heading = document.createElement("div"); heading.className = "dialog-heading"; const symbol = document.createElement("span"); symbol.className = "dialog-symbol"; symbol.textContent = "＋"; const headingText = document.createElement("div"); const eyebrow = document.createElement("p"); eyebrow.className = "eyebrow"; eyebrow.textContent = "REGISTRO LOCAL"; const h2 = document.createElement("h2"); h2.textContent = title; headingText.append(eyebrow, h2); heading.append(symbol, headingText);
    const form = document.createElement("form"); form.className = "stack-form";
    fields.forEach((field) => { const label = document.createElement("label"); label.textContent = field.label; const input = document.createElement("input"); input.name = field.name; input.type = field.type || "text"; input.required = field.required !== false; input.placeholder = field.placeholder || ""; if (field.min) input.min = field.min; if (field.step) input.step = field.step; label.append(input); form.append(label); });
    const actions = document.createElement("div"); actions.className = "dialog-actions"; const cancel = document.createElement("button"); cancel.type = "button"; cancel.className = "button button-quiet"; cancel.textContent = "Cancelar"; cancel.addEventListener("click", () => dialog.close()); const save = document.createElement("button"); save.type = "submit"; save.className = "button button-primary"; save.textContent = submitLabel; actions.append(cancel, save); form.append(actions);
    form.addEventListener("submit", (event) => { event.preventDefault(); const values = Object.fromEntries(new FormData(form).entries()); if (onSubmit(values)) dialog.close(); });
    dialog.append(close, heading, form); document.body.append(dialog); dialog.addEventListener("close", () => dialog.remove()); dialog.showModal(); return dialog;
  }
  $(`[data-add-bill]`)?.addEventListener("click", () => createSimpleDialog("Adicionar conta", [{ name: "name", label: "Nome da conta", placeholder: "Ex.: Água" }, { name: "amount", label: "Valor (R$)", type: "number", min: "0.01", step: "0.01" }, { name: "date", label: "Data de vencimento", type: "date" }, { name: "category", label: "Categoria", placeholder: "Ex.: Contas da casa" }], "Salvar conta", (values) => {
    const cents = centsFromInput(values.amount); if (!cents || !values.date) { showToast("Informe valor e vencimento válidos.", true); return false; }
    state.bills.push({ id: crypto.randomUUID?.() || `bill-${Date.now()}`, name: values.name.trim(), amount_cents: cents, due_date: values.date, category: values.category.trim() || "Outros", status: "a_vencer", transaction_id: "" }); saveStore("Conta adicionada."); return true;
  }));
  $(`[data-bill-list]`)?.addEventListener("click", (event) => {
    const button = event.target.closest("[data-pay-bill]"); if (!button) return;
    const bill = state.bills.find((item) => item.id === button.dataset.payBill); if (!bill) return;
    const billStatus = effectiveBillStatus(bill);
    if (billStatus === "paga" || !window.confirm(`Marcar “${bill.name}” como paga?`)) return;
    const recordExpense = window.confirm("Também registrar o valor total como uma despesa? Se você já lançou as compras individualmente ou não quiser criar outra saída, escolha Cancelar. A conta ainda será marcada como paga.");
    const id = crypto.randomUUID?.() || `bill-expense-${Date.now()}`;
    if (recordExpense && (!bill.transaction_id || !state.transactions.some((item) => item.id === bill.transaction_id))) {
      state.transactions.push({ id, date: localIsoDate(), description: bill.name, category: bill.category || "Outros", type: "despesa", status: "confirmada", amount_cents: bill.amount_cents }); bill.transaction_id = id;
    }
    bill.status = "paga"; saveStore(recordExpense ? "Conta marcada como paga; despesa registrada." : "Conta marcada como paga sem nova despesa.");
  });
  $(`[data-add-goal]`)?.addEventListener("click", () => createSimpleDialog("Criar uma meta", [{ name: "name", label: "Nome da meta", placeholder: "Ex.: Curso" }, { name: "target", label: "Valor-alvo (R$)", type: "number", min: "0.01", step: "0.01" }, { name: "monthly", label: "Contribuição mensal planejada (R$)", type: "number", min: "0", step: "0.01", required: false }], "Criar meta", (values) => {
    const target = centsFromInput(values.target); const monthly = values.monthly ? Math.round(Number(values.monthly) * 100) : 0;
    if (!target || !Number.isSafeInteger(monthly) || monthly < 0) { showToast("Confira os valores da meta.", true); return false; }
    state.goals.push({ id: crypto.randomUUID?.() || `goal-${Date.now()}`, name: values.name.trim(), target_cents: target, current_cents: 0, monthly_cents: monthly }); saveStore("Meta criada."); return true;
  }));
  $(`[data-goal-list]`)?.addEventListener("submit", (event) => {
    const form = event.target.closest("[data-goal-form]"); if (!form) return;
    event.preventDefault(); const amount = centsFromInput($("input", form).value); const goal = state.goals.find((item) => item.id === form.dataset.goalForm);
    if (!goal || !amount) { showToast("Informe uma contribuição válida.", true); return; }
    goal.current_cents = Math.min(goal.target_cents, goal.current_cents + amount); form.reset(); saveStore("Progresso da meta atualizado.");
  });
  $(`[data-reserve-form]`)?.addEventListener("submit", async (event) => {
    event.preventDefault(); const form = event.currentTarget; const cents = centsFromInput(form.elements.expenses.value); const months = Number(form.elements.months.value);
    if (!cents) { showToast("Informe despesas essenciais válidas.", true); return; }
    try { const result = await postJson("/api/reserva", { expenses_cents: cents, months }); const target = $(`[data-reserve-target]`); if (target) target.textContent = moneyText(result.target_cents); const detail = $(`[data-reserve-detail]`); if (detail) detail.textContent = `${result.months} meses × ${moneyText(result.monthly_expenses_cents)} por mês · valor ilustrativo`; }
    catch (error) { showToast(error.message, true); }
  });
  $(`[data-period]`)?.addEventListener("change", refreshSummary);
  $(`[data-toggle-privacy]`)?.addEventListener("click", (event) => {
    const hidden = document.body.classList.toggle("is-private"); event.currentTarget.setAttribute("aria-pressed", String(hidden)); event.currentTarget.setAttribute("aria-label", hidden ? "Mostrar valores" : "Ocultar valores");
  });
  $(`[data-dismiss-banner]`)?.addEventListener("click", (event) => event.currentTarget.closest(".demo-banner")?.remove());

  $(`[data-export-csv]`)?.addEventListener("click", () => {
    const rows = [["Data", "Descrição", "Tipo", "Categoria", "Status", "Valor em centavos"], ...state.transactions.map((item) => [item.date, item.description, item.type, item.category, item.status, item.amount_cents])];
    const csv = "\uFEFF" + rows.map((row) => row.map(escapeCsv).join(";")).join("\r\n");
    downloadFile(csv, "finflow-movimentacoes.csv", "text/csv;charset=utf-8"); showToast("Arquivo CSV preparado.");
  });
  $(`[data-export-json]`)?.addEventListener("click", () => { downloadFile(JSON.stringify(state, null, 2), "finflow-backup.json", "application/json"); showToast("Backup JSON preparado."); });
  function downloadFile(contents, filename, type) {
    const url = URL.createObjectURL(new Blob([contents], { type })); const link = document.createElement("a"); link.href = url; link.download = filename; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  $(`[data-import-json]`)?.addEventListener("change", async (event) => {
    const file = event.target.files?.[0]; if (!file) return;
    if (file.size > 1_048_576) { showToast("O arquivo de backup pode ter no máximo 1 MB.", true); event.target.value = ""; return; }
    try {
      const parsed = JSON.parse(await file.text());
      const checked = await postJson("/api/resumo", { data: parsed, period: "current" });
      if (!Array.isArray(parsed.transactions) || !Array.isArray(parsed.budgets) || !Array.isArray(parsed.bills) || !Array.isArray(parsed.goals)) throw new Error("O arquivo não parece ser um backup FinFlow válido.");
      if (!window.confirm("Substituir os dados atuais pelo conteúdo deste backup?")) return;
      state = parsed; localStorage.setItem(STORE_KEY, JSON.stringify(state)); updateSummary(checked); showToast("Backup restaurado neste navegador.");
    } catch (error) { showToast(error.message || "Não foi possível restaurar o backup.", true); }
    finally { event.target.value = ""; }
  });

  $$(`[data-category-filters] [data-category-filter]`).forEach((button) => button.addEventListener("click", () => {
    $$(`[data-category-filters] [data-category-filter]`).forEach((item) => item.classList.toggle("is-selected", item === button)); filterArticles(button.dataset.categoryFilter);
  }));
  $(`[data-article-search]`)?.addEventListener("input", () => {
    $$(`[data-objective-query]`).forEach((button) => button.classList.remove("is-selected"));
    filterArticles($("[data-category-filters] [data-category-filter].is-selected")?.dataset.categoryFilter || "todas");
  });
  $(`[data-level-filter]`)?.addEventListener("change", () => filterArticles($("[data-category-filters] [data-category-filter].is-selected")?.dataset.categoryFilter || "todas"));
  $$(`[data-objective-query]`).forEach((button) => button.addEventListener("click", () => {
    const search = $(`[data-article-search]`); if (!search) return;
    search.value = button.dataset.objectiveQuery; search.focus();
    $$(`[data-objective-query]`).forEach((item) => item.classList.toggle("is-selected", item === button));
    filterArticles($("[data-category-filters] [data-category-filter].is-selected")?.dataset.categoryFilter || "todas");
  }));
  function filterArticles(category) {
    const query = ($(`[data-article-search]`)?.value || "").trim().toLocaleLowerCase("pt-BR");
    const level = $(`[data-level-filter]`)?.value || "todos"; let count = 0;
    $$(`[data-article-card]`).forEach((card) => {
      const matchCategory = category === "todas" || card.dataset.category === category;
      const matchQuery = !query || card.dataset.search.includes(query);
      const matchLevel = level === "todos" || card.dataset.level === level;
      card.hidden = !(matchCategory && matchQuery && matchLevel); if (!card.hidden) count++;
    });
    const empty = $(`[data-article-empty]`); if (empty) empty.hidden = count > 0;
  }
  filterArticles($("[data-category-filters] [data-category-filter].is-selected")?.dataset.categoryFilter || "todas");

  renderTransactionTable();
  renderBills();
  renderGoals();
  refreshSummary();
})();
